import React from 'react';
import TaskCard from './components/TaskCard';

function App() {
  return (
    <div>
      <h1>Blockchain Learn Game</h1>
      <TaskCard title="Solve hash puzzle" description="Learn how hashing works in blockchain." />
    </div>
  );
}

export default App;
