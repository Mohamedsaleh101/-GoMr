import React from 'react';

interface Props { title: string; description: string; }

export default function TaskCard({ title, description }: Props) {
  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', margin: '1rem 0' }}>
      <h2>{title}</h2>
      <p>{description}</p>
    </div>
  );
}
